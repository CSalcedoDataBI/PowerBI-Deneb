# Escenario — Grupos de cálculo: un formato por elemento

Copia del maestro `deneb-incubadora/_contoso-maestro` con **una** página de escenario
añadida, para el post [Grupos de cálculo en Power BI: su formato en
Deneb](https://csalcedodatabi.com/blog/grupos-calculo-formato-deneb/).

| | |
|---|---|
| Proyecto | `Grupos de cálculo en Deneb.pbip` |
| Modelo | `ContosoRetail.SemanticModel` (sin renombrar: el modelo **es** Contoso) |
| Páginas | `Thank You!!` (del maestro) + **4 escenarios** de grupos de cálculo |

## Qué se añadió sobre el maestro

- **Tres grupos de cálculo**: `Formato` (precedencia 10), `Herencia` (20) y `TimeIntel` (30).
  El primero (`tables/Formato.tmdl`) lleva tres elementos:
  `Valor original` (sin formato propio), `En miles` y `Porcentaje del total`. Solo los dos
  últimos declaran `formatStringDefinition`.
- **Página del escenario** con un visual Deneb en **Vega-Lite** que proyecta
  `Formato[Formato]` como categoría y `[Total Sales]` como medida, y muestra en columnas el
  valor crudo, `__formatted` y `__format`.

## Lo medido

| Elemento | Crudo | `__formatted` | `__format` |
|---|---|---|---|
| Valor original | 19903677,62 | `$19,903,678` | `\$#,0` |
| En miles | 19903,68 | `$19,903.7 K` | `\$#,0.0 "K"` |
| Porcentaje del total | 1 | `100.00%` | `0.00%` |

## Los cuatro escenarios de grupos de calculo

Este archivo trae **todos** los ejemplos de grupos de calculo del laboratorio, replicados sobre
Contoso. Tres grupos en el modelo y una pagina por caso. Al abrirlo, la pagina **Indice** lista
los cuatro escenarios y lleva a cada uno; cada escenario tiene botones para volver al indice o
pasar al siguiente (en Desktop, Ctrl + clic).

| Pagina | Grupo | Que demuestra |
|---|---|---|
| 1 · Un formato por elemento | `Formato` | El elemento impone su formato sobre el de la medida |
| 2 · Herencia del formato | `Herencia` | `SELECTEDMEASUREFORMATSTRING()` respeta el formato de CADA medida; uno fijo lo aplasta |
| 3 · Cruzado con fechas | `Formato` | El formato se resuelve por celda al cruzar con un eje de tiempo. Una matriz nativa y dos segmentadores (elemento y anio) acompanian al visual de Deneb |
| 4 · Comparativa interanual | `TimeIntel` | Cuatro elementos de comparacion con el anio anterior y **solo** `Diferencia %` cambia el formato |

Medido en la comparativa interanual (ventas por anio):

| | Medida seleccionada | Anio anterior | Diferencia | Diferencia % |
|---|---|---|---|---|
| 2023 | `$9,516,546` | - | `$9,516,546` | - |
| 2024 | `$10,387,132` | `$9,516,546` | `$870,586` | **`9.1%`** |

Tres columnas conservan la moneda de la medida; solo la ultima sale en porcentaje, igual que en
una tabla nativa de Power BI.

Contoso cubre 2023-2024, asi que 2023 no tiene anio anterior: `Diferencia` iguala al total
porque restar en blanco no resta. No es un fallo del grupo, es el borde del calendario.

## Dos cosas que cuestan tiempo si no se saben

1. **`discourageImplicitMeasures` es obligatorio** — ya viene puesto en el maestro. Sin él, el
   grupo de cálculo no se aplica y parece que falla Deneb.
2. **El visual tiene que estar en `provider: vegaLite`.** El visual donante del maestro viene
   en `vega`; con un spec de Vega-Lite dentro, el lienzo sale **vacío y sin ningún error**.

## Datos

El `.zip` de `entrega/` **no lleva `cache.abf`**: al abrirlo hay que refrescar. La fuente es
el [Contoso Retail público](https://github.com/CSalcedoDataBI/SampleDataSets/tree/main/contoso-retail).
Si Power BI avisa de que los grupos de cálculo necesitan actualizarse, pulsa *Refresh now*:
recalcula los grupos sin recargar datos.
