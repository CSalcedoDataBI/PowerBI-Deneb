# Escenario — Grupos de cálculo: un formato por elemento

Copia del maestro `deneb-incubadora/_contoso-maestro` con **una** página de escenario
añadida, para el post [Grupos de cálculo en Power BI: su formato en
Deneb](https://csalcedodatabi.com/blog/grupos-calculo-formato-deneb/).

| | |
|---|---|
| Proyecto | `Grupos de cálculo en Deneb.pbip` |
| Modelo | `ContosoRetail.SemanticModel` (sin renombrar: el modelo **es** Contoso) |
| Páginas | `Thank You!!` (del maestro) + **4 escenarios** de grupos de cálculo |

## Qué se añadió sobre el maestro

- **Tres grupos de cálculo**: `Formato` (precedencia 10), `Herencia` (20) y `TimeIntel` (30).
  El primero (`tables/Formato.tmdl`) lleva tres elementos:
  `Valor original` (sin formato propio), `En miles` y `Porcentaje del total`. Solo los dos
  últimos declaran `formatStringDefinition`.
- **Página del escenario** con un visual Deneb en **Vega-Lite** que proyecta
  `Formato[Formato]` como categoría y `[Total Sales]` como medida, y muestra en columnas el
  valor crudo, `__formatted` y `__format`.

## Lo medido

| Elemento | Crudo | `__formatted` | `__format` |
|---|---|---|---|
| Valor original | 19903677,62 | `$19,903,678` | `\$#,0` |
| En miles | 19903,68 | `$19,903.7 K` | `\$#,0.0 "K"` |
| Porcentaje del total | 1 | `100.00%` | `0.00%` |

## Los cuatro escenarios de grupos de calculo

Este archivo trae **todos** los ejemplos de grupos de calculo del laboratorio, replicados sobre
Contoso. Tres grupos en el modelo y una pagina por caso.

| Pagina | Grupo | Que demuestra |
|---|---|---|
| Grupos de calculo: un formato por elemento | `Formato` | El elemento impone su formato sobre el de la medida |
| Herencia: cada medida conserva su formato | `Herencia` | `SELECTEDMEASUREFORMATSTRING()` respeta el formato de CADA medida; uno fijo lo aplasta |
| Grupo de calculo sobre fechas | `Formato` | El formato se resuelve por celda al cruzar con un eje de tiempo |
| Caso original de deneb#522 | `TimeIntel` | Cuatro elementos de time intelligence y **solo** `Diferencia %` cambia el formato |

Medido en el caso #522 (ventas por anio):

| | Medida seleccionada | Anio anterior | Diferencia | Diferencia % |
|---|---|---|---|---|
| 2023 | `$9,516,546` | - | `$9,516,546` | - |
| 2024 | `$10,387,132` | `$9,516,546` | `$870,586` | **`9.1%`** |

Tres columnas conservan la moneda de la medida; solo la ultima sale en porcentaje. Ese es el
caso que reporta deneb#522.

Contoso cubre 2023-2024, asi que 2023 no tiene anio anterior: `Diferencia` iguala al total
porque restar en blanco no resta. No es un fallo del grupo, es el borde del calendario.

## Dos cosas que cuestan tiempo si no se saben

1. **`discourageImplicitMeasures` es obligatorio** — ya viene puesto en el maestro. Sin él, el
   grupo de cálculo no se aplica y parece que falla Deneb.
2. **El visual tiene que estar en `provider: vegaLite`.** El visual donante del maestro viene
   en `vega`; con un spec de Vega-Lite dentro, el lienzo sale **vacío y sin ningún error**.

## Datos

El `.zip` de `entrega/` **no lleva `cache.abf`**: al abrirlo hay que refrescar. La fuente es
el [Contoso Retail público](https://github.com/CSalcedoDataBI/SampleDataSets/tree/main/contoso-retail).
Al abrir tras añadir el grupo de cálculo, Power BI pide un refresco de grupos de cálculo — es
esperable y se resuelve con *Refresh now*.
