# Escenario — Herencia: cada medida conserva su formato

Copia del maestro `deneb-incubadora/_contoso-maestro` con **una** página de escenario añadida,
para el post [Heredar el formato de la medida en Power BI con
Deneb](https://csalcedodatabi.com/blog/heredar-formato-medida-deneb/).

| | |
|---|---|
| Proyecto | `Herencia del formato en Deneb.pbip` |
| Modelo | `ContosoRetail.SemanticModel` (sin renombrar: el modelo **es** Contoso) |
| Páginas | `Thank You!!` (del maestro) · `Herencia: cada medida conserva su formato` |

## Qué se añadió sobre el maestro

**Grupo de cálculo `Herencia`** (`tables/Herencia.tmdl`, precedencia 20) con tres elementos:

- `Original` — sin formato propio
- `Miles (formato fijo)` — `formatStringDefinition = "#,0.0 ""K"""`
- `Miles (formato heredado)` — `formatStringDefinition = SELECTEDMEASUREFORMATSTRING() & " ""K"""`

Y una página con un visual Deneb en **Vega-Lite** que proyecta `Herencia[Herencia]` junto a **tres
medidas de unidades distintas**, que es lo que hace visible el contraste: `Total Sales` (moneda),
`Total Quantity` (número) y `Margin %` (porcentaje).

## Lo medido

La cadena de formato que recibe cada medida:

| Elemento | `Total Sales__format` | `Total Quantity__format` | `Margin %__format` |
|---|---|---|---|
| Original | `\$#,0` | `#,0` | `0.0%` |
| Miles (formato fijo) | `#,0.0 "K"` | `#,0.0 "K"` | `#,0.0 "K"` |
| Miles (formato heredado) | `\$#,0 "K"` | `#,0 "K"` | `0.0% "K"` |

En la fila del formato fijo **las tres son idénticas**: el elemento las aplasta al mismo molde, y
por eso un margen del 19,8 % acaba mostrándose como `0.0 K`.

## Trampas ya pagadas en este escenario

1. **`discourageImplicitMeasures` es obligatorio** — viene puesto en el maestro. Sin él, el grupo
   de cálculo no se aplica y parece que falla Deneb.
2. **El visual donante del maestro viene en `provider: "vega"`.** Con un spec de Vega-Lite dentro,
   el lienzo sale **vacío y sin ningún error**. Tiene que estar en `vegaLite`.
3. **El caché de datos es anterior al grupo de cálculo**, así que Power BI pide procesarlo al
   abrir. Se resuelve con *Refresh now*, o por XMLA sin tocar la interfaz.
4. **La ventana de Desktop puede quedar minimizada** y entonces `PrintWindow` devuelve una captura
   en blanco sin avisar. Antes de capturar hay que comprobar `IsIconic` y el tamaño real:
   `MainWindowHandle` llega a resolver a una ventana auxiliar de 160x28.

## Ciclo en caliente

Para editar el spec **no hace falta cerrar Power BI**:

```
save_visual_spec(pbip_path, page_id, visual_name, spec: "<json>", refresh: true)
```

Escribe el `visual.json` y recarga el lienzo en el mismo proceso. Lo que NO hace es cambiar de
página: para eso sigue haciendo falta reabrir.

## Datos

El `.zip` de `entrega/` **no lleva `cache.abf`**: al abrirlo hay que refrescar. La fuente es el
[Contoso Retail público](https://github.com/CSalcedoDataBI/SampleDataSets/tree/main/contoso-retail).
